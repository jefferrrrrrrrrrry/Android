package com.example.job.ui.search;

import androidx.lifecycle.ViewModel;

public class SearchViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}